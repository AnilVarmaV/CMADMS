--**********************************************************
-- Engine Database
-- ---------------------------------------------------------
-- Licensed Materials - Property of IBM
-- �Restricted Materials of IBM�
-- 5725-C15
-- � Copyright IBM Corp. 1994, 2015 All Rights Reserved
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

-- Version 9.0.1.3   Updated 10/17/2015
-- 8.1.0.1 11/21/2011 32534 RFerin - changed qu_id to be auto increment
-- 8.1.0.1 11/29/2011 32534 RFerin - Added db_version column.
-- 8.1.0.2 01/11/2012 33534 RFerin - Changed Batch ID lengths to 50
-- 9.0.0.3 04/21/2014 68839 RFerin - Identity was missing on some DB2 tables
-- 9.0.0.4 07/17/2014 98230 RFerin - Set the columns rp_comments and rfValue to 3000.
-- 9.0.0.5 05/30/2014 82479 NSK - Add DB2 compound index to improve grab batch times ()
-- 9.0.0.6 10/10/2014 105854 NSK - JobMonitor performance left->inner join
-- 9.0.1.0 09/22/2015 132156 - Removed empty comments that can sometimes cause script errors.
-- 9.0.1.1 10/09/2015 132424, 116227, 128713 - reportTotal & reportBatch accuracy stats, statistics table consolidation, JM views
-- 9.0.1.2 10/14/2015 133504 corrected insert into reporTotal
-- 9.0.1.3 10/17/2015 133504 add r[bt]Feature2Count, r[bt]_FieldLowConfCorrectPct, r[bt]_FieldLocConfErrorPct 

-- IBM DB2 Engine Database
--**********************************************************
-- Description: Creates a New DB2 Engine Database
--              This creates the tables and includes a small amount of inital data to help bootstrap Taskmaster.

-- REQUIREMENT: This script requires the target database to have
--              a "Default bufferpool and table space page size" of 8K.

-- REMEMBER: for right datatime representation use trigger:

-- Create or replace trigger winlogontrigger
--   after logon on database
-- begin
--   execute immediate
--     'alter session set NLS_DATE_FORMAT="MM/DD/YYYY HH24:MI:SS"';
-- end;


CREATE TABLE TMBATCH(
   PB_BATCH       VARCHAR (50)      NOT NULL,    -- should have one to one relationship with the queue table in TMaster
   PB_EXPECTPGS   DECIMAL (10,0) WITH DEFAULT 0, -- expected pages in the batch
   PB_NDOCS       DECIMAL (10,0) WITH DEFAULT 0, -- number of complete documents
   PB_MRDATE      TIMESTAMP                    , -- date batch received
   PB_BATCHDIR    VARCHAR (128)                , -- Batch directory, scan task will put it here, recog and edit will use it.
   PB_HEADERTABLE VARCHAR (16)                 , -- table with batch header info (Scan task pass it to TM and Export and Verify may request it)
   PB_PAGEFILE    VARCHAR (255)                , -- file name for page file
   PB_PAGES       DECIMAL (10,0)               ,
   PB_ADJUSTPAGES DECIMAL (10,0)               ,
   PB_EXPECTDOCS  DECIMAL (10,0)               ,
   PB_ADJUSTDOCS  DECIMAL (10,0)               ,
   PB_PARENTBATCH VARCHAR (50)                 , -- by default it is an empty string, otherwise ID of a parent batch for a sub(mini) batch
   PB_NEEDMEET    DECIMAL (10,0) WITH DEFAULT 0, -- First byte: 1 - if this is a parent who needs to meet children, Second byte: 1 - if it is a child who need to meet own parent
   PB_STATIONID   VARCHAR (110)                , -- optionally stored station id which ran the task
   PB_USERID      VARCHAR (255)					, -- optional stored userID 
   PB_KEY         BIGINT						, -- group or role based tag */
   CONSTRAINT
         PK_TMBATCH PRIMARY KEY (pb_batch)
 );

CREATE INDEX  PARENTBATCH  ON TMBATCH ( pb_parentbatch);

CREATE TABLE QUEUE(
   -- QU_ID          DECIMAL (10,0) WITH DEFAULT 0 NOT NULL, -- Queue Logical Name (Pre 8.1 Schema)
   QU_ID          DECIMAL (10,0) NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   QU_JOB         VARCHAR (100)                ,   -- job associasted with queue
   QU_TASK        VARCHAR (100)                ,   -- current (or last) task running in queue
   QU_TSORDER     DECIMAL (10,0) WITH DEFAULT 0,   -- order number of task in job
   QU_STATUS      VARCHAR (16)                 ,   -- queue status (running, done, suspended, canceled, aborted)
   QU_START       TIMESTAMP                    ,   -- first task started
   QU_DONE        TIMESTAMP                    ,   -- done time for most recent task
   QU_PRIORITY    DECIMAL (3,0)  WITH DEFAULT 0,   -- Queue priority
   QU_SOURCE      VARCHAR (16)                ,    -- the source that start create the entry, usually the scan station.
   QU_PARENT      DECIMAL (10,0) WITH DEFAULT 0,   -- number of queue entry for parent job from the same batch
   QU_BATCH       VARCHAR (50)                 ,   -- Batch ID
   QU_ELAPS       DECIMAL (10,0) WITH DEFAULT 0,
   QU_SPAWNTYPE   DECIMAL (10,0) WITH DEFAULT 0,   -- status code for parent job to be used to set this parent job when children return
   QU_LOCK        VARCHAR (130)  DEFAULT 'none',   -- Field for implementation of critical section locking
   QU_ADMDB       DECIMAL (10,0) WITH DEFAULT 0,   -- admin database index
   QU_COUNTER     DECIMAL (10,0)               ,   -- A couter of children if any
   CONSTRAINT
         PK_QUEUE PRIMARY KEY ( qu_id),
   CONSTRAINT
         FK_QU_BATCH FOREIGN KEY (qu_batch)
                     REFERENCES TMBATCH ( pb_batch ) ON DELETE CASCADE
);

CREATE  INDEX  ADMINDEX           ON QUEUE ( qu_admDB );
CREATE  INDEX  ID_START_ORDER     ON QUEUE ( qu_start,qu_tsorder,qu_id);
CREATE  INDEX  JOB_TASK           ON QUEUE ( qu_job,qu_task );
CREATE  INDEX  PRIORITY_START_ID  ON QUEUE ( qu_priority,qu_start,qu_id);
CREATE  INDEX  QU_BATCH           ON QUEUE ( qu_batch );
CREATE  INDEX  QU_JOB             ON QUEUE ( qu_job );
CREATE  INDEX  QU_STATUS          ON QUEUE ( qu_status );
CREATE  INDEX  QU_TASK            ON QUEUE ( qu_task );
CREATE  INDEX  QU_GRAB            ON QUEUE ( qu_id, qu_task, qu_job, qu_status, qu_lock, qu_admDB, qu_counter, qu_priority, qu_start);
CREATE  INDEX  QU_TASK_PRIO_START_ID  ON QUEUE ( qu_task,qu_priority,qu_start,qu_id);
CREATE  INDEX  QU_ELAPS_STATUS    ON QUEUE ( qu_elaps, qu_status);
CREATE  INDEX  QU_JOB_TASK_STATUS ON QUEUE (qu_job, qu_task, qu_status);

-- we have primary index PK_QUEUE on this column
-- CREATE UNIQUE INDEX QU_ID ON QUEUE ( qu_id );

CREATE TABLE QSTATS(
   QS_QID         DECIMAL (10,0) WITH DEFAULT 0 NOT NULL, -- queue ID for this task
   QS_TASKID      VARCHAR (100)                 NOT NULL, -- task id
   QS_TSORDER     DECIMAL (10,0) WITH DEFAULT 0 NOT NULL, -- order number of task in job
   QS_STATION     VARCHAR (110)                ,          -- station associated with task
   QS_OP          VARCHAR (255)                ,          -- operator associated with task
   QS_START       TIMESTAMP                    ,          -- start task date/time stamp
   QS_STOP        TIMESTAMP                    ,          -- end task date/time stamp
   QS_ELAPS       DECIMAL(10,0)  WITH DEFAULT 0,
   QS_OPSKIP      VARCHAR (255),
   QS_STSKIP      VARCHAR (110),
   CONSTRAINT
         PK_QSTATS PRIMARY KEY ( qs_qid,qs_taskid,qs_tsorder),
   CONSTRAINT
         FK_QS_QID FOREIGN KEY ( qs_qid)
                     REFERENCES QUEUE ( qu_id ) ON DELETE CASCADE
);

CREATE  INDEX  QS_QID      ON QSTATS ( qs_qid );
CREATE  INDEX  QS_TASKID   ON QSTATS ( qs_taskid );
CREATE  INDEX  QS_TSORDER  ON QSTATS ( qs_tsorder );
CREATE  INDEX  QS_GRAB     ON QSTATS( qs_qid, qs_taskid, qs_station, qs_op, qs_stSkip, qs_opSkip);

CREATE TABLE ENGINFO(
   DB_ID        VARCHAR (16)                 , -- ODBC Driver logical name (key to driver table)
   DB_LOC       VARCHAR (128)                , -- Location of network database
   DB_LASTBATCH VARCHAR (50)                 , -- Last used batch ID
   DB_LASTQUEUE DECIMAL (10,0) WITH DEFAULT 0, -- Last used queue ID
   DB_LASTDATE  TIMESTAMP                    , -- Date when last time batch ID was generated
   DB_INDEX     DECIMAL (10,0) WITH DEFAULT 0 NOT NULL,
   DB_VERSION   DECIMAL (5,0)  NOT NULL  WITH DEFAULT 1 -- Database schema version
   );

CREATE TABLE DIRTYFLAG(
   DF_TIME      VARCHAR (50)
);
                            -- last time when run time info was changed


-- Statistic tables

CREATE TABLE DEBUG(
   DG_USERID              VARCHAR (255),
   DG_TASKID              VARCHAR (100),
   DG_JOBID               VARCHAR (100),
   DG_TIME                TIMESTAMP,
   DG_STATUS              VARCHAR (50),
   DG_MANUAL              DECIMAL (10,0) WITH DEFAULT 0,
   DG_STATIONID           VARCHAR (110),
   DG_BATCH               VARCHAR (50),
   DG_QUID                DECIMAL (10,0) WITH DEFAULT 0,
   DG_OLDSTATUS           VARCHAR (50),
   DG_OLDTASK             VARCHAR (100),
   DG_LNTIME              DECIMAL (10,0)
);
CREATE  INDEX  DBG_QUEUE  ON DEBUG ( dg_quid );

CREATE TABLE TASKSTATS(
   TS_BATCHID             VARCHAR (50)          NOT NULL, -- The batch identification number
   TS_JOBNAME             VARCHAR (100)                 , -- The name of the job
   TS_TASKNAME            VARCHAR (100)                 , -- The name of the Task
   TS_OPERATOR            VARCHAR (255)                 , -- The name of the Operator
   TS_STATION             VARCHAR (110)                 , -- The station that processed the task
   TS_STARTTIME           TIMESTAMP                     , -- The exact start time of the task  'MM/DD/CCYY HH:MM:SS (AM or PM)'
   TS_ELAPSEDSEC          DECIMAL (10,0) WITH DEFAULT 0 , -- The number of seconds used by the task during execution
   TS_PAGESINBATCH        DECIMAL (10,0) WITH DEFAULT 0 , -- The total number of pages
   TS_PROCESSEDPAGES      DECIMAL (10,0) WITH DEFAULT 0 , -- The total number of processed pages
   TS_DOCSINBATCH         DECIMAL (10,0) WITH DEFAULT 0 , -- The total number of documents
   TS_PROCESSEDDOCS       DECIMAL (10,0) WITH DEFAULT 0 , -- The total number of processed documents
   TS_STATUS              VARCHAR (16)                  , -- Task Status
   TS_REMARK              VARCHAR (255)                 , -- Notes, Remarks or comments.
   TS_KEYSTROKES          DECIMAL (10,0) WITH DEFAULT 0
);


CREATE INDEX  BATCHID_1  ON TASKSTATS ( ts_BatchID );
CREATE INDEX  JOBNAME    ON TASKSTATS ( ts_JobName );
CREATE INDEX  TASKNAME   ON TASKSTATS ( ts_TaskName );
CREATE INDEX  OPERATOR   ON TASKSTATS ( ts_Operator );
CREATE INDEX  STATION    ON TASKSTATS ( ts_Station );

CREATE TABLE UPLOADST(
   UP_BATCHID             VARCHAR (50)         NOT NULL,
   UP_JOBID               VARCHAR (100)                ,
   UP_TASKID              VARCHAR (100)                ,
   UP_OPERATOR            VARCHAR (255)                ,
   UP_STATION             VARCHAR (110)                ,
   UP_ELAPSEDTIME         DECIMAL (10,0) WITH DEFAULT 0,
   UP_START               TIMESTAMP                         ,
   UP_END                 TIMESTAMP                         ,
   UP_DOCS                DECIMAL (10,0) WITH DEFAULT 0,
   UP_PAGES               DECIMAL (10,0) WITH DEFAULT 0);

CREATE INDEX  UP_BATCHID_IND  ON UPLOADST ( up_BatchID);
CREATE INDEX  UP_JOBID_IND    ON UPLOADST ( up_JobID );
CREATE INDEX  UP_TASKID_IND   ON UPLOADST ( up_TaskID );

--- CREATE BUFFERPOOL sessionBP SIZE 1000 PAGESIZE 8K

CREATE TABLE reportFilters(
   rfID                INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   rfName              VARCHAR (255) ,
   rfReport            VARCHAR (255) ,
   rfUser              VARCHAR (255) ,
   rfPublic            VARCHAR (255) ,
   rfValue             VARCHAR (3000));


CREATE TABLE reportUsers(
   ID                  INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   ru_ip               VARCHAR (255),
   ru_job              VARCHAR (255),
   ru_port             DECIMAL (10,0) WITH DEFAULT 0,
   ru_batches          DECIMAL (10,0) WITH DEFAULT 0,
   ru_station          VARCHAR (255),
   ru_task             VARCHAR (255),
   ru_user             VARCHAR (255),
   ru_time             TIMESTAMP         );


CREATE TABLE reportTotal(
    rt_PageCount			DECIMAL (10,0) WITH DEFAULT 0,
	rt_DocCount				DECIMAL (10,0) WITH DEFAULT 0,
	rt_BatchCount			DECIMAL (10,0) WITH DEFAULT 0,
    rt_Feature1Count		DECIMAL (10,0) WITH DEFAULT 0,
	rt_Feature2Count		DECIMAL (10,0) WITH DEFAULT 0,
	rt_TotalSizeKB			DECIMAL (10,0) WITH DEFAULT 0,
	rt_FieldAccuracyPct			DECIMAL (10,2) WITH DEFAULT 0,
	rt_FieldAccuracyWeight		DECIMAL (10,2) WITH DEFAULT 0,
	rt_FieldLowConfCorrectPct	DECIMAL (10,2) WITH DEFAULT 0,
	rt_FieldLowConfErrorPct		DECIMAL (10,2) WITH DEFAULT 0,
	rt_ClassifyAccuracyPct		DECIMAL (10,2) WITH DEFAULT 0,
	rt_ClassifyAccuracyWeight	DECIMAL (10,2) WITH DEFAULT 0,
	rt_ClassifyLowConfCorrectPct DECIMAL (10,2) WITH DEFAULT 0,
	rt_ClassifyLowConfErrorPct DECIMAL (10,2) WITH DEFAULT 0,
	rt_DocTypeAccuracyPct		DECIMAL (10,2) WITH DEFAULT 0,
	rt_DocTypeAccuracyWeight	DECIMAL (10,2) WITH DEFAULT 0,
	rt_DocTypeLowConfCorrectPct DECIMAL (10,2) WITH DEFAULT 0,
	rt_DocTypeLowConfErrorPct	DECIMAL (10,2) WITH DEFAULT 0
	); 
   

CREATE TABLE reportBatch(
   ID                  INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   rb_batch            VARCHAR (50),
   rb_batchtype        VARCHAR (255),
   rb_job              VARCHAR (255),
   rb_time             TIMESTAMP,
   rb_Source           VARCHAR (50),
   rb_SizeKB            DECIMAL (10,0) WITH DEFAULT 0,
	rb_Feature1Count    DECIMAL (10,0) WITH DEFAULT 0,
	rb_Feature2Count    DECIMAL (10,0) WITH DEFAULT 0,
	rb_FieldAccuracyPct			DECIMAL (10,2) WITH DEFAULT 0,
	rb_FieldAccuracyWeight		DECIMAL (10,2) WITH DEFAULT 0,
	rb_FieldLowConfCorrectPct	DECIMAL (10,2) WITH DEFAULT 0,
	rb_FieldLowConfErrorPct		DECIMAL (10,2) WITH DEFAULT 0,
	rb_ClassifyAccuracyPct		DECIMAL (10,2) WITH DEFAULT 0,
	rb_ClassifyAccuracyWeight	DECIMAL (10,2) WITH DEFAULT 0, 
	rb_ClassifyLowConfCorrectPct DECIMAL (10,2) WITH DEFAULT 0,
	rb_ClassifyLowConfErrorPct	DECIMAL (10,2) WITH DEFAULT 0,
	rb_DocTypeAccuracyPct		DECIMAL (10,2) WITH DEFAULT 0,
	rb_DocTypeAccuracyWeight	DECIMAL (10,2) WITH DEFAULT 0, 
	rb_DocTypeLowConfCorrectPct DECIMAL (10,2) WITH DEFAULT 0,
	rb_DocTypeLowConfErrorPct	DECIMAL (10,2) WITH DEFAULT 0 
	);
	
CREATE  INDEX  rb_batch  ON reportBatch ( rb_batch );

CREATE TABLE reportField(
   ID                  INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   rf_batch            VARCHAR (50),
   rf_batchtype        VARCHAR (255),
   rf_document         VARCHAR (255),
   rf_documenttype     VARCHAR (255),
   rf_job              VARCHAR (255),
   rf_page             VARCHAR (255),
   rf_pagetype         VARCHAR (255),
   rf_fieldtype        VARCHAR (255),
   rf_status           VARCHAR (255),
   rf_statuspreverify  VARCHAR (255),
   rf_charschanged			DECIMAL (10,0) WITH DEFAULT 0,
   rf_time					TIMESTAMP,
   rf_recognizedchars		DECIMAL (10,0) WITH DEFAULT 0,
   rf_recognizedcharslc		DECIMAL (10,0) WITH DEFAULT 0,
   rf_FieldAccuracyPct		DECIMAL (10,2) WITH DEFAULT 0,
   rf_FieldAccuracyWeight	DECIMAL (10,2) WITH DEFAULT 0,
   rf_FieldLowConfCorrectPct DECIMAL (10,2) WITH DEFAULT 0,
   rf_FieldLowConfErrorPct	DECIMAL (10,2) WITH DEFAULT 0
	);
	
CREATE TABLE reportPage(
   ID                  INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   rp_batch            VARCHAR (50),
   rp_batchtype        VARCHAR (255),
   rp_document         VARCHAR (255),
   rp_documenttype     VARCHAR (255),
   rp_job              VARCHAR (255),
   rp_page             VARCHAR (255),
   rp_pagetype         VARCHAR (255),
   rp_fpfound          VARCHAR (255),
   rp_fpcreated        VARCHAR (255),
   rp_verifyoperator   VARCHAR (255),
   rp_verifystation    VARCHAR (255),
   rp_verifytime       TIMESTAMP         ,
   rp_statuspostverify VARCHAR (255),
   rp_statuspreverify  VARCHAR (255),
   rp_status           VARCHAR (255),
   rp_comments         VARCHAR (3000),
   rp_time             TIMESTAMP         );

CREATE TABLE reportDocument(
   ID                  INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   rd_batch            VARCHAR (50) ,
   rd_batchtype        VARCHAR (255) ,
   rd_document         VARCHAR (255) ,
   rd_documenttype     VARCHAR (255) ,
   rd_job              VARCHAR (255) ,
   rd_status           VARCHAR (255) ,
   rd_statuspreverify  VARCHAR (255) ,
   rd_time             TIMESTAMP          );


CREATE TABLE NENU(
   ID                  INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   nn_batch            VARCHAR (50)  ,
   nn_attempt          DECIMAL (10,0) WITH DEFAULT 0,
   nn_done             TIMESTAMP          ,
   nn_action           VARCHAR (255) ,
   CONSTRAINT
         PK_NENU PRIMARY KEY (ID),
   CONSTRAINT
         FK_NN_BATCH FOREIGN KEY (nn_batch)
                     REFERENCES TMBATCH ( pb_batch ) ON DELETE CASCADE
);


-- Start UPDATE CASCADE triggers


-- TR_TMBATCH
-- Split into 2 Triggers

CREATE OR REPLACE TRIGGER TR_TMBATCH
   AFTER UPDATE ON TMBATCH
REFERENCING NEW AS N OLD AS O
FOR EACH ROW
 When (N.PB_BATCH <> O.PB_BATCH)
      UPDATE "QUEUE"
         SET QU_BATCH = N.PB_BATCH
         WHERE QU_BATCH = O.PB_BATCH;

CREATE OR REPLACE TRIGGER TR_TMBATCH
   AFTER UPDATE ON TMBATCH
REFERENCING NEW AS N OLD AS O
FOR EACH ROW
 When (N.PB_BATCH <> O.PB_BATCH)
      UPDATE "NENU"
         SET NN_BATCH = N.PB_BATCH
         WHERE NN_BATCH = O.PB_BATCH;


-- TR_QUEUE

CREATE OR REPLACE TRIGGER TR_QUEUE
   AFTER UPDATE ON QUEUE
REFERENCING NEW AS N OLD AS O
FOR EACH ROW
 WHEN (N.QU_ID <> O.QU_ID)
      UPDATE "QSTATS"
         SET QS_QID = N.QU_ID
         WHERE QS_QID = O.QU_ID;



-- JMVIEW

CREATE OR REPLACE VIEW JMVIEW  AS
SELECT  tmbatch.*, queue.qu_admDB qu_admDB, queue.qu_id qu_id,
                      queue.qu_batch, queue.qu_job qu_job,
                      queue.qu_task qu_task, queue.qu_tsorder qu_tsorder,
                      queue.qu_status qu_status, queue.qu_priority qu_priority,
                      queue.qu_parent qu_parent, queue.qu_start qu_start,
                      queue.qu_elaps qu_elaps, queue.qu_counter qu_counter,
                      qstats.qs_start qs_start, qstats.qs_elaps qs_elaps,
                      qstats.qs_op qs_op, qstats.qs_station qs_station,
                      qstats.qs_opSkip qs_opSkip, qstats.qs_stSkip qs_stSkip
    FROM tmbatch, queue
        LEFT OUTER JOIN qstats on  ((queue.qu_id = qstats.qs_qid) AND (queue.qu_task = qstats.qs_taskid))

    WHERE (tmbatch.pb_batch= queue.qu_batch);


CREATE OR REPLACE VIEW JOBMONITOR  AS
SELECT  tmbatch.*, queue.*, qstats.*
        FROM tmbatch, queue
    INNER JOIN qstats on ((queue.qu_id = qstats.qs_qid) AND (queue.qu_task = qstats.qs_taskid))
    WHERE (tmbatch.pb_batch = queue.qu_batch);


CREATE OR REPLACE VIEW MAXQUEUEID  AS
SELECT  MAX(qu_id) maxid
        FROM queue;

CREATE OR REPLACE VIEW QUEUEQSTATS  AS
SELECT  qu_id, qu_start, qs_start, qs_station, qs_op
        FROM queue, qstats
        WHERE ((queue.qu_task = qstats.qs_taskid) AND (queue.qu_id = qstats.qs_qid));


--  DIRTYFLAG

insert into DIRTYFLAG(df_time)
   Values('10/29/2001 10:18:10 AM 1 169165737');


--  ENGINFO

-- 9.0.1 schema version changed from 1 to 2
insert into ENGINFO(db_id, db_loc, db_LastBatch, db_LastQueue, db_LastDate, db_index, db_version)
   Values('Engine', 'none', '20020141.001', 10, '2/2/2004', 7, 2);

--  REPORTTOTAL

insert into reportTotal(rt_PageCount,rt_DocCount,rt_BatchCount,rt_Feature1Count,rt_Feature2Count,rt_TotalSizeKB,rt_FieldAccuracyPct,rt_ClassifyAccuracyPct,rt_FieldAccuracyWeight, rt_ClassifyAccuracyWeight,rt_FieldLowConfCorrectPct,rt_FieldLowConfErrorPct,rt_ClassifyLowConfCorrectPct,rt_ClassifyLowConfErrorPct,rt_DocTypeAccuracyPct,rt_DocTypeAccuracyWeight,rt_DocTypeLowConfCorrectPct,rt_DocTypeLowConfErrorPct) Values (0,0,0,0,0,0,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.);