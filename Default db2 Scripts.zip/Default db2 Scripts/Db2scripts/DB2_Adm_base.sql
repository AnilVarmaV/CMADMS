--**********************************************************
-- Admin Database
-- ---------------------------------------------------------
-- Licensed Materials - Property of IBM
-- �Restricted Materials of IBM�
-- 5725-C15 
-- � Copyright IBM Corp. 1994, 2015 All Rights Reserved
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

-- Version 9.0.1  Created 10/14/2015 - Created DB2 script based on Oracle script.
-- 8.1.1   11/29/2011 32534 RFerin - Added db_version column.
-- 9.0.1.0 09/22/2015 132156 - Removed empty comments that can sometimes cause script errors.
-- 9.0.1.1 10/14/2015 - tables and fields added for view by role

-- IBM DB2 Admin Database
--**********************************************************
-- Description: Creates a New DB2 Admin Database
--              This creates the tables and includes a small amount of inital data to help bootstrap Taskmaster.

-- SET DEFINE OFF


CREATE TABLE VIEWS(
   VW_ID                INT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
   VW_KEY              BIGINT,
   VW_COLUMNS          VARCHAR (255) ,
   VW_ORDER            VARCHAR (3000) );  

CREATE TABLE BUTTONS ( 
    BTN_BUTTONNAME   VARCHAR (255) ,                                  -- Button caption
    BTN_BUTTONNUMBER DECIMAL (5, 0)  NOT NULL  WITH DEFAULT 0 ,       -- Order number on the top level screen (main menu screen)
    BTN_BATCHSELECTIONMODE DECIMAL (3, 0)  NOT NULL  WITH DEFAULT 0 , -- This field can be 1, 2 or 0. 1 - Always auto, 2 - always manual, 0 - prompt
    BTN_DESC         VARCHAR (255)  NOT NULL ,                        -- description
    BTN_FILENAME     VARCHAR (255)  NOT NULL ,                        -- File name with path for icon
    BTN_ICONINDEX    DECIMAL (5, 0)  NOT NULL  WITH DEFAULT 0  ,      -- 0-based index for icon
    CONSTRAINT PK_BUTTONS PRIMARY KEY ( BTN_BUTTONNUMBER)  ) ;

COMMENT ON BUTTONS ( 
             BTN_BUTTONNAME IS 'Button caption', 
             BTN_DESC IS 'Description', 
             BTN_ICONINDEX IS '0-based index for icon', 
             BTN_BATCHSELECTIONMODE IS 'This field can be 1, 2 or 0. 1 - Always auto, 2 - always manual, 0 - prompt', 
             BTN_FILENAME IS 'File name with path for icon', 
             BTN_BUTTONNUMBER IS 'Order number on the top level screen (main menu screen)' ) ;


CREATE  UNIQUE INDEX  BTN_BUTTONNAME  ON BUTTONS ( btn_ButtonName );


CREATE TABLE DCO ( 
   DCO_ID VARCHAR (100)  NOT NULL ,                    -- Unique index
   DCO_DESCRIPTION VARCHAR (255) ,                     -- Description of DCObject
   DCO_OLEID VARCHAR (255) ,                           -- DCObject Ole class ID
   DCO_SETUPPARAM CLOB  (1 M )  NOT  LOGGED  COMPACT , -- Optional params string to pass to DCObject in setup time
   DCO_RUNPARAM CLOB  (1 M )  NOT LOGGED  COMPACT ,    -- Optional params string to pass to DCObject in run time
   DCO_IND DECIMAL (5, 0)  NOT NULL  WITH DEFAULT 0 ,  -- unique index
   DCO_SETUP VARCHAR (255)  ,                          -- setup string - just like setup string for a task
   CONSTRAINT PK_DCO PRIMARY KEY ( DCO_IND)  ) ;

COMMENT ON DCO ( DCO_IND IS 'Unique index', 
                 DCO_RUNPARAM IS 'Optional params string to pass to DCObject in run time', 
                 DCO_OLEID IS 'DCObject Ole class ID', 
                 DCO_ID IS 'DCObject  name/id, must be unique', 
                 DCO_DESCRIPTION IS 'Description of DCObject', 
                 DCO_SETUP IS 'Setup string - just like setup string for a task', 
                 DCO_SETUPPARAM IS 'Optional params string to pass to DCObject in setup time' ) ;


CREATE  UNIQUE INDEX  DCO_ID_IND     ON DCO ( dco_id );
CREATE         INDEX  DCO_OLEID_IND  ON DCO ( dco_oleid );


CREATE TABLE JOB ( 
   JB_ID VARCHAR (100) ,                                 -- job logical name (key to other tables) 
   JB_DESC VARCHAR (255) ,                               -- text description of job
   JB_PRIORITY DECIMAL (3, 0) NOT NULL  WITH DEFAULT 0 , -- Job Priority.
   JB_FS VARCHAR (100) ,                                 -- Full path to a PK formspec (or other file which determine form processing)
   JB_IND INTEGER  NOT NULL  WITH DEFAULT 0  ,           -- uniq index
   CONSTRAINT PK_JOB PRIMARY KEY ( JB_IND)  ) ;

COMMENT ON JOB ( JB_ID IS 'Job logical name (key to other tables)', 
                 JB_FS IS 'Full path to a PK formspec (or other file which determine form processing)', 
                 JB_IND IS 'Unique Index', 
                 JB_DESC IS 'Text description of job', 
                 JB_PRIORITY IS 'Job Priority' ) ;



CREATE TABLE DCOJOB ( 
   DCO_IND DECIMAL (5, 0)  WITH DEFAULT 0 ,    -- DCObject index
   JOB_IND DECIMAL (5, 0)  WITH DEFAULT 0 ,    -- Job index
   CONSTRAINT 
         FK_DCO_IND FOREIGN KEY ( dco_ind )
                    REFERENCES DCO ( dco_ind )
                         ON DELETE CASCADE,
   CONSTRAINT
         FK_JOB_IND FOREIGN KEY ( job_ind )
                    REFERENCES JOB ( jb_ind ) 
                         ON DELETE CASCADE 

) ;   

COMMENT ON DCOJOB ( DCO_IND IS 'DCObject index', JOB_IND IS 'Job Index' ) ;


CREATE  INDEX  DCO_IND_IND  ON DCOJOB ( dco_ind );
CREATE  INDEX  JOB_IND_IND  ON DCOJOB ( job_ind );


CREATE TABLE STATION ( 
   STA_ID         VARCHAR (100)  NOT NULL ,         -- Station Id,
   STA_DESC       VARCHAR (255) ,                   -- Station description.
   IN_USE         DECIMAL (3, 0) ,                  -- Station being used?
   STA_USER       DECIMAL (5, 0)  WITH DEFAULT 0 ,  -- User ID
   STA_TASK       DECIMAL (5, 0)  WITH DEFAULT 0 ,  -- active task
   STA_LOGINTIME  TIMESTAMP ,                       -- Login Time
   STA_QUID       DECIMAL (10, 0)  WITH DEFAULT 0 , -- Current queue ID
   STA_LOGOUTTIME TIMESTAMP ,                       -- Logout time
   STA_RUNNING    DECIMAL (5, 0)  WITH DEFAULT 0 ,  -- 0 if nothing is running, ortherwise Engine DB Index
   STA_IND        DECIMAL (5, 0) NOT NULL ,         -- uniq number
   STA_MAXN       DECIMAL (5, 0)  WITH DEFAULT 0 ,  -- maximum number of stations with this ID
   STA_N          DECIMAL (5, 0)  WITH DEFAULT 0,   -- current number of stations with this ID
   CONSTRAINT
         PK_STATION PRIMARY KEY ( Sta_id ),
   CONSTRAINT 
         STA_IND UNIQUE ( Sta_ind )
) ;

COMMENT ON STATION ( 
   STA_IND IS 'Unique number', 
   STA_RUNNING IS '0 if nothing is running, ortherwise Engine DB Index', 
   STA_DESC IS 'Station description.', 
   STA_TASK IS 'Active task', 
   STA_LOGOUTTIME IS 'Logout time', 
   STA_LOGINTIME IS 'Login time', 
   STA_MAXN IS 'maximum number of stations with this ID', 
   STA_USER IS 'User ID', STA_ID IS 'Station ID', 
   IN_USE IS 'Station being used?', 
   STA_QUID IS 'Current queue ID', 
   STA_N IS 'Current number of stations with this ID' ) ;

-- CREATE  UNIQUE INDEX  STA_IND  ON STATION ( Sta_ind );

CREATE TABLE TASKMOD(
   IND            DECIMAL (5,0)   NOT NULL  WITH DEFAULT 0, -- internal uniq index
   MD_NAME        VARCHAR (255)             NOT NULL,       -- Must be unique, used as id in the tm_Selecttask prog
   MD_DESC        VARCHAR (255),                            -- description of module 
   MD_EXE         VARCHAR (255),                            -- Full path to task application
   MD_APPSIGN     VARCHAR (50) ,                            -- Application signature
   MD_CREATIVE    DECIMAL (5,0)   NOT NULL  WITH DEFAULT 0, -- Yes - if task is job creation task, No - if a regular task
   MD_TABLE       VARCHAR (50) ,                            -- Statistics table name
   MD_FIELD       VARCHAR (50) ,                            -- Field name for batch ID in statistics table
   MD_PARAMS      VARCHAR (255),                            -- Module params - command line params alike
   CONSTRAINT 
         PK_TASKMOD PRIMARY KEY ( md_name ),
   CONSTRAINT 
         MD_IND Unique ( ind )
);


COMMENT ON TASKMOD ( 
   IND          IS  'internal uniq index',
   MD_NAME      IS  'Must be unique, used as id in the tm_Selecttask prog',
   MD_DESC      IS  'description of module',
   MD_EXE       IS  'Full path to task application',
   MD_APPSIGN   IS  'Application signature',
   MD_CREATIVE  IS  'Yes - if task is job creation task, No - if a regular task',
   MD_TABLE     IS  'Statistics table name',
   MD_FIELD     IS  'Field name for batch ID in statistics table',
   MD_PARAMS    IS  'Module params - command line params alike'
			 ) ;


CREATE TABLE TASKS(
   TS_ID          VARCHAR (100),                            -- task logical name
   TS_DESC        VARCHAR (255),                            -- text description of task
   TS_RUN_NUM     DECIMAL (5,0)   WITH DEFAULT 0,           -- run task module index
   TS_MON         DECIMAL (5,0)   WITH DEFAULT 0,           -- determine how task monitor is shown during this task is running, 0 means normal, 1 Always on top, 2 minimized
   TS_OPTIONS     CLOB,                                     
   TS_IND         DECIMAL (5,0)   WITH DEFAULT 0   NOT NULL,-- uniq number
   TS_DECIS       DECIMAL (5,0)   WITH DEFAULT -1,          -- index for attached decision maker
   TS_RUNWHOWHERE DECIMAL (3,0)   WITH DEFAULT 0,           -- Next task after this will be assigned to the same user-station
   TS_STOREIDS    DECIMAL (3,0)   WITH DEFAULT 0,           -- Store station ID so that later we can come back to this station
   CONSTRAINT 
         PK_TASKS PRIMARY KEY ( ts_ind ),
   CONSTRAINT
         FK_TS_RUN_NUM FOREIGN KEY ( ts_run_num )
                       REFERENCES TASKMOD ( ind )
                            ON DELETE CASCADE
);
-- Note: here is a foreign key which is not based on the primary key


COMMENT ON TASKS ( 
   TS_ID          IS 'task logical name',
   TS_DESC        IS 'text description of task',
   TS_RUN_NUM     IS 'run task module index',
   TS_MON         IS 'determine how task monitor is shown during this task is running, 0 means normal, 1 Always on top, 2 minimized',   
   TS_IND         IS 'uniq number',
   TS_DECIS       IS 'index for attached decision maker',
   TS_RUNWHOWHERE IS 'Next task after this will be assigned to the same user-station',
   TS_STOREIDS    IS 'Store station ID so that later we can come back to this station'
			 ) ;


CREATE  UNIQUE INDEX  TS_ID   ON TASKS ( ts_id );

CREATE TABLE JOBTASK(
   JT_ORDER      DECIMAL (5,0)  WITH DEFAULT 0 NOT NULL, -- Task's order in job ( 0 is job creation task )
   JT_JOB_IND    DECIMAL (5,0)  WITH DEFAULT 0 NOT NULL, -- job index
   JT_TASK_IND   DECIMAL (5,0)  WITH DEFAULT 0 NOT NULL, -- task index
   JT_IND        DECIMAL (5,0)  WITH DEFAULT 0 NOT NULL, -- uniq number
   CONSTRAINT
         PK_JOBTASK PRIMARY KEY (jt_order,jt_job_ind,jt_task_ind ),
   CONSTRAINT  
         FK_JT_TASK_IND FOREIGN KEY ( jt_task_ind ) 
                        REFERENCES TASKS ( ts_ind )
                             ON DELETE CASCADE,
   CONSTRAINT
         FK_JT_JOB_IND FOREIGN KEY ( jt_job_ind ) 
                        REFERENCES JOB ( jb_ind )
                             ON DELETE CASCADE,
   CONSTRAINT
         JT_IND Unique ( jt_ind )
);

COMMENT ON JOBTASK ( 
   JT_ORDER     IS 'A tasks order in job - 0 is job creation task',
   JT_JOB_IND   IS 'job index',
   JT_TASK_IND  IS 'task index',
   JT_IND       IS 'uniq number'
			 ) ;

CREATE TABLE LOGGEDSTATIONS(
   LS_SERVERID   VARCHAR (50)            NOT NULL, -- unique server ID generated randomly
   LS_STATIONIND DECIMAL (5,0) NOT NULL  WITH DEFAULT 0, -- station index from station table
   CONSTRAINT 
         FK_LS_STATIONIND FOREIGN KEY ( ls_stationInd )
                          REFERENCES STATION ( sta_ind ) 
                               ON DELETE CASCADE
);

COMMENT ON LOGGEDSTATIONS ( 
   LS_SERVERID    IS 'unique server ID generated randomly',
   LS_STATIONIND  IS 'station index from station table'
			 ) ;

CREATE  INDEX  LS_SERVERID_IND    ON LOGGEDSTATIONS ( ls_serverID );
CREATE  INDEX  LS_STATIONIND_IND  ON LOGGEDSTATIONS ( ls_stationInd );

CREATE TABLE TMGROUP(
   GR_IND        DECIMAL (5,0)  WITH DEFAULT 0 NOT NULL, -- uniq id
   GR_NAME       VARCHAR (255)                 NOT NULL, -- Text ID
   GR_DESC       VARCHAR (255),                          -- text description
   GR_PRIV       DECIMAL (10,0)  WITH DEFAULT 0,         -- group permissions
   GR_KEY 		BIGINT,
   CONSTRAINT 
         PK_TMGROUP PRIMARY KEY ( gr_ind )
);

COMMENT ON TMGROUP ( 
   GR_IND     IS   'uniq id',
   GR_NAME    IS   'Text ID',
   GR_DESC    IS   'text description',
   GR_PRIV    IS   'group permissions'
			 ) ;

CREATE  UNIQUE INDEX  GR_NAME  ON TMGROUP ( gr_name );

CREATE TABLE TMUSER(
   US_ID         VARCHAR (255)             NOT NULL, -- User Id.
   US_NAME       VARCHAR (255),                      -- User name,
   US_PASS       VARCHAR (255),                       -- User password.
   US_PERM       DECIMAL (10,0)  NOT NULL  WITH DEFAULT 0, -- 3 means administrator, 2 just a supervisor
   US_IND        DECIMAL (5,0)   NOT NULL  WITH DEFAULT 0, -- uniq number
   CONSTRAINT
         PK_TMUSER PRIMARY KEY ( us_id ),
   CONSTRAINT
         us_ind UNIQUE ( us_ind )
);

COMMENT ON TMUSER ( 
   US_ID     IS  'User Id.',
   US_NAME   IS  'User name',
   US_PASS   IS  'User password.',
   US_PERM   IS  '3 means administrator, 2 just a supervisor',
   US_IND    IS  'uniq number'
			 ) ;


CREATE TABLE FUNCTIONS(
   FC_BTN_IND    DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0,  -- index of the button (comes from 'Buttons' table)
   FC_JBTS_IND   DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0,  -- index of job task pair (from 'jobtask' table)
   CONSTRAINT
         PK_FUNCTIONS PRIMARY KEY ( fc_btn_ind,fc_jbts_ind ),
   CONSTRAINT
         FK_FC_BTN_IND FOREIGN KEY ( fc_btn_ind )
                    REFERENCES BUTTONS ( btn_ButtonNumber ) 
                         ON DELETE CASCADE,
   CONSTRAINT
         FK_FC_JBTS_IND FOREIGN KEY ( fc_jbts_ind )
                    REFERENCES JOBTASK ( jt_ind )
                         ON DELETE CASCADE
);


COMMENT ON FUNCTIONS ( 
   FC_BTN_IND   IS 'index of the button (comes from Buttons table)',
   FC_JBTS_IND  IS 'index of job task pair (from jobtask table)'
			 ) ;


CREATE TABLE GROUPTASK(
   GROUPIND      DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, -- index from 'tmgroup'
   JBTSIND       DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, -- index from 'jobtask'
   CONSTRAINT
         PK_GROUPTASK PRIMARY KEY ( GroupInd,jbtsInd ),
   CONSTRAINT  FK_GROUPIND FOREIGN KEY ( GroupInd )
                           REFERENCES TMGROUP ( gr_ind ) 
                                ON DELETE CASCADE, 
   CONSTRAINT  FK_JBTSIND1 FOREIGN KEY ( jbtsInd )
                           REFERENCES JOBTASK ( jt_ind )
                                ON DELETE CASCADE
);

COMMENT ON GROUPTASK ( 
   GROUPIND    IS  'index from tmgroup',
   JBTSIND     IS  'index from jobtask'
			 ) ;


CREATE TABLE LASTJOB(
   LJ_USER_IND   DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0,  
   LJ_JBTS_IND   DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0,  -- this number comes from 'jobtask' table. This number is uniq in 'jobtask'.
   CONSTRAINT 
         PK_LASTJOB PRIMARY KEY ( lj_user_ind,lj_jbts_ind ),
   CONSTRAINT
         FK_LJ_USER_IND FOREIGN KEY ( lj_user_ind )
                        REFERENCES TMUSER ( us_ind )
                             ON DELETE CASCADE,
   CONSTRAINT
         FK_LJ_JBTS_IND FOREIGN KEY ( lj_jbts_ind )
                        REFERENCES JOBTASK ( jt_ind )
                             ON DELETE CASCADE
);

COMMENT ON LASTJOB ( 
    LJ_JBTS_IND   IS 'this number comes from jobtask table. This number is uniq in jobtask.'
			 ) ;


CREATE TABLE PERIODIC(
   PR_CHECKJOB   DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, -- job ID for the checking proccess (from job table)
   PR_PERIOD     DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, -- Each 'period' task go to supervisor
   PR_COUNTER    DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, 
   PR_RANDOM     DECIMAL (3,0)  NOT NULL,                 -- Can be 0 or 1. 1 means generate control job in random mode
   PR_GROUP      DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, -- index from group table
   PR_JBTS_IND   DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, -- this number comes from 'jobtask' table. This number is uniq in 'jobtask'.
   CONSTRAINT 
         PK_PERIODIC PRIMARY KEY ( pr_Group,pr_jbts_ind ),
   CONSTRAINT
         FK_PR_CHECKJOB FOREIGN KEY ( pr_CheckJob )
                        REFERENCES JOB ( jb_ind )
                             ON DELETE CASCADE,
   CONSTRAINT
         FK_PR_JBTS_IND FOREIGN KEY ( pr_jbts_ind ) 
                        REFERENCES JOBTASK ( jt_ind )
                             ON DELETE CASCADE,
   CONSTRAINT
         FK_PR_GROUP FOREIGN KEY ( pr_Group )
                        REFERENCES TMGROUP ( gr_ind )
                             ON DELETE CASCADE 
);

COMMENT ON PERIODIC ( 
   PR_CHECKJOB   IS 'job ID for the checking proccess (from job table)',
   PR_PERIOD     IS 'Each period task go to supervisor',
   PR_RANDOM     IS 'Can be 0 or 1. 1 means generate control job in random mode',
   PR_GROUP      IS 'index from group table',
   PR_JBTS_IND   IS 'this number comes from jobtask table. This number is uniq in jobtask.'
			 ) ;


CREATE TABLE SPAWN(
   SP_CONDITION  DECIMAL (5,0)   NOT NULL  WITH DEFAULT 0, -- order number for a condition
   SP_JBTS_IND   DECIMAL (5,0)   NOT NULL  WITH DEFAULT 0, -- index from 'jobtask' table
   SP_NEWJOB_IND DECIMAL (5,0)   NOT NULL  WITH DEFAULT 0, -- index from 'job'
   SP_OPTION     DECIMAL (10,0)  NOT NULL  WITH DEFAULT 0, -- this field is bit mask, do not edit it manually
   SP_ID         VARCHAR (255),                            -- condition's name/id
   CONSTRAINT
         PK_SPAWN PRIMARY KEY ( sp_condition,sp_jbts_ind ),
   CONSTRAINT
         FK_SP_NEWJOB_IND FOREIGN KEY ( sp_newJob_ind )
                        REFERENCES JOB ( jb_ind )
                             ON DELETE CASCADE,
   CONSTRAINT
         FK_SP_JBTS_IND FOREIGN KEY ( sp_jbts_ind )
                        REFERENCES JOBTASK ( jt_ind )
                             ON DELETE CASCADE
 );

COMMENT ON SPAWN ( 
   SP_CONDITION  IS 'order number for a condition',
   SP_JBTS_IND   IS 'index from jobtask table',
   SP_NEWJOB_IND IS 'index from job',
   SP_OPTION     IS 'this field is bit mask, do not edit it manually',
   SP_ID         IS 'conditions name/id'
			 ) ;


CREATE  INDEX  SP_ID_IND  ON SPAWN ( sp_id );

CREATE TABLE STATIONTASK(
   STATIONIND     DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, -- index from 'station' table
   JBTSIND        DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, -- index from 'jobtask' table
   CONSTRAINT 
         PK_STATIONTASK PRIMARY KEY ( stationInd,jbtsInd ),
   CONSTRAINT
         FK_STATIONIND FOREIGN KEY ( stationInd )
                        REFERENCES STATION ( sta_ind )
                             ON DELETE CASCADE,
   CONSTRAINT
         FK_JBTSIND3 FOREIGN KEY ( jbtsInd )
                        REFERENCES JOBTASK ( jt_ind )
                             ON DELETE CASCADE
);

COMMENT ON STATIONTASK ( 
   STATIONIND  IS 'index from station table',
   JBTSIND     IS 'index from jobtask table'
			 ) ;


CREATE TABLE USERGROUP(
   UG_GROUPIND    DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, -- group index
   UG_USERIND     DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, -- user index
   CONSTRAINT
         PK_USERGROUP PRIMARY KEY ( ug_userind,ug_groupind ),
   CONSTRAINT
         FK_UG_GROUPIND FOREIGN KEY ( ug_groupind )
                        REFERENCES TMGROUP ( gr_ind )
                             ON DELETE CASCADE,
   CONSTRAINT  FK_UG_USERIND FOREIGN KEY ( ug_userind )
                        REFERENCES TMUSER ( us_ind )
                             ON DELETE CASCADE
);

COMMENT ON USERGROUP ( 
   UG_GROUPIND IS 'group index',
   UG_USERIND  IS 'user index'
			 ) ;


CREATE TABLE USERTASK(
   USERIND        DECIMAL (5,0) NOT NULL  WITH DEFAULT 0, -- index from 'tmuser'
   JBTSIND        DECIMAL (5,0) NOT NULL  WITH DEFAULT 0, -- index from 'jobtask'
   CONSTRAINT
         PK_USERTASK PRIMARY KEY ( UserInd,jbtsInd ),
   CONSTRAINT
         FK_USERIND FOREIGN KEY ( UserInd )
                        REFERENCES TMUSER ( us_ind )
                             ON DELETE CASCADE,
   CONSTRAINT
         FK_JBTSIND2 FOREIGN KEY ( jbtsInd )
                        REFERENCES JOBTASK ( jt_ind )
                             ON DELETE CASCADE
);

COMMENT ON USERTASK ( 
   USERIND  IS 'index from tmuser',
   JBTSIND  IS 'index from jobtask'
			 ) ;


CREATE TABLE ADMINFO(
   DB_ID          VARCHAR (16)             NOT NULL, -- ODBC Driver logical name (key to driver table)
   DB_LOC         VARCHAR (128)            NOT NULL, -- Location of newtwork database
   DB_APPTITLE    VARCHAR (50)             NOT NULL, -- Application title
   DB_INDEX       DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0,
   DB_VERSION     DECIMAL (5,0)  NOT NULL  WITH DEFAULT 0, -- Database schema version
   DB_KEYMODE		INT
);

COMMENT ON ADMINFO ( 
   DB_ID        IS 'ODBC Driver logical name (key to driver table)',
   DB_LOC       IS 'Location of newtwork database',
   DB_APPTITLE  IS 'Application title'
			 ) ;

CREATE TABLE AUDIT(
   AU_USERID      VARCHAR (255),
   AU_TIME        TIMESTAMP,
   AU_ACTION      VARCHAR (255) 
);
CREATE  INDEX AU_USERID_IND ON AUDIT( au_UserID );


--- Views --

CREATE OR REPLACE VIEW JBTSTSMD  AS
SELECT  jobtask.*, taskmod.md_creative, taskmod.md_name, jb_id jt_job, ts_id jt_task
 FROM jobtask, tasks, taskmod, job 
    WHERE jobtask.jt_task_ind = tasks.ts_ind 
     AND tasks.ts_run_num = taskmod.ind
     AND jb_ind = jt_job_ind;

CREATE OR REPLACE VIEW QJOBTASK  AS
SELECT  jobtask.jt_order, job.jb_id, tasks.ts_id, jobtask.jt_ind
 FROM tasks, job, jobtask
    WHERE (job.jb_ind = jobtask.jt_job_ind) AND (tasks.ts_ind = jobtask.jt_task_ind);

CREATE OR REPLACE VIEW QUSERGROUP  AS
SELECT  tmgroup.gr_name, tmuser.us_id
 FROM tmuser, tmgroup, usergroup
    WHERE (tmgroup.gr_ind = usergroup.ug_groupind) AND (tmuser.us_ind = usergroup.ug_userind);

CREATE OR REPLACE VIEW "TASK"AS
SELECT  tasks.ts_id, tasks.ts_desc, tasks.ts_mon, tasks.ts_options, taskmod.md_name ts_run, tasks.ts_run_num, taskmod.md_creative, taskmod.ind
 FROM taskmod, tasks
    WHERE (taskmod.ind = tasks.ts_run_num);

CREATE OR REPLACE VIEW QFUNCTION  AS
SELECT  qJobTask.ts_id, qJobTask.jb_id, qJobTask.jt_order
 FROM Buttons, functions, qJobTask
    WHERE (functions.fc_jbts_ind = qJobTask.jt_ind) AND (Buttons.btn_ButtonNumber = functions.fc_btn_ind);

CREATE OR REPLACE VIEW QGROUPTASK  AS 
SELECT  tmgroup.gr_name, qJobTask.ts_id, qJobTask.jb_id, qJobTask.jt_order
 FROM tmgroup, qJobTask, grouptask
    WHERE (qJobTask.jt_ind = grouptask.jbtsInd) AND (tmgroup.gr_ind = grouptask.GroupInd);

CREATE OR REPLACE VIEW QLASTJOB  AS
SELECT  tmuser.us_id, qJobTask.jb_id, qJobTask.ts_id
 FROM tmuser, lastjob, qJobTask
    WHERE (lastjob.lj_jbts_ind = qJobTask.jt_ind) AND (tmuser.us_ind = lastjob.lj_user_ind);

CREATE OR REPLACE VIEW QLOGGEDSTATIONS  AS
SELECT  station.Sta_id, LoggedStations.ls_serverID, station.sta_ind, station.sta_N, station.In_use
 FROM station, LoggedStations
    WHERE (station.sta_ind = LoggedStations.ls_stationInd);

CREATE OR REPLACE VIEW QSTATIONTASK  AS
SELECT  station.Sta_id, qJobTask.jb_id, qJobTask.ts_id
 FROM station, stationtask, qJobTask
    WHERE (stationtask.jbtsInd = qJobTask.jt_ind) AND (station.sta_ind = stationtask.stationInd);

CREATE OR REPLACE VIEW QUSERTASK  AS
SELECT  tmuser.us_id, qJobTask.jb_id, qJobTask.ts_id
 FROM tmuser, usertask, qJobTask
    WHERE (usertask.jbtsInd = qJobTask.jt_ind) AND (tmuser.us_ind = usertask.UserInd);



--  Triggers for UPDATE CASCADE


create or replace trigger tr_buttons
after update of btn_ButtonNumber on buttons
REFERENCING NEW AS N OLD AS O
for each row
WHEN  ( N.btn_ButtonNumber <> O.btn_ButtonNumber) 
      update "FUNCTIONS"
         set fc_btn_ind = N.btn_ButtonNumber
         where fc_btn_ind = O.btn_ButtonNumber;

create or replace trigger tr_station1  -- Had to split into two updates
after update on station
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.sta_ind <> O.sta_ind)
      update LOGGEDSTATIONS
         set ls_stationInd = N.sta_ind
         where ls_stationInd = O.sta_ind;

create or replace trigger tr_station2
after update on station
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.sta_ind <> O.sta_ind)
      update STATIONTASK
         set stationInd = N.sta_ind
         where stationInd = O.sta_ind;


create or replace trigger tr_tmuser1 -- had to split into 1, 2 and 3
after update on tmuser
REFERENCING NEW AS N OLD AS O
for each row
When (N.us_ind <> O.us_ind) 
      update LASTJOB
         set lj_user_ind = N.us_ind
         where lj_user_ind = O.us_ind;

create or replace trigger tr_tmuser2
after update on tmuser
REFERENCING NEW AS N OLD AS O
for each row
When (N.us_ind <> O.us_ind) 
      update USERTASK
         set UserInd = N.us_ind
         where UserInd = O.us_ind;


create or replace trigger tr_tmuser3
after update on tmuser
REFERENCING NEW AS N OLD AS O
for each row
When (N.us_ind <> O.us_ind) 
      update USERGROUP
         set ug_userind = N.us_ind
         where ug_userind = O.us_ind;


-- TMGROUP Trigger
-- Split into 3 updates

create or replace trigger tr_tmgroup1 
after update on tmgroup
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.gr_ind <> O.gr_ind) 
      update PERIODIC
         set pr_Group = N.gr_ind
         where pr_Group = O.gr_ind;


create or replace trigger tr_tmgroup2
after update on tmgroup
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.gr_ind <> O.gr_ind) 
      update GROUPTASK
         set GroupInd = N.gr_ind
         where GroupInd = O.gr_ind;

		 
create or replace trigger tr_tmgroup3
after update on tmgroup
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.gr_ind <> O.gr_ind) 
      update USERGROUP
         set ug_groupind = N.gr_ind
         where ug_groupind = O.gr_ind;


-- JOB Trigger
-- Split into 4 updates

create or replace trigger tr_job1
after update on job
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.jb_ind <> O.jb_ind) 
      update PERIODIC
         set pr_CheckJob = N.jb_ind
         where pr_CheckJob = O.jb_ind;

create or replace trigger tr_job2
after update on job
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.jb_ind <> O.jb_ind) 
      update JOBTASK
         set jt_job_ind = N.jb_ind
         where jt_job_ind = O.jb_ind;

create or replace trigger tr_job3
after update on job
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.jb_ind <> O.jb_ind) 
      update DCOJOB
         set job_ind = N.jb_ind
         where job_ind = O.jb_ind;

create or replace trigger tr_job4
after update on job
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.jb_ind <> O.jb_ind) 
      update SPAWN
         set sp_newJob_ind = N.jb_ind
         where sp_newJob_ind = O.jb_ind;



-- JOBTASK Trigger
-- Split into 5 updates

create or replace trigger tr_jobtaskA1
after update on jobtask
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.jt_ind <> O.jt_ind) 
      update SPAWN
         set sp_jbts_ind = N.jt_ind
         where sp_jbts_ind = O.jt_ind;


create or replace trigger tr_jobtaskA2
after update on jobtask
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.jt_ind <> O.jt_ind) 
      update PERIODIC
         set pr_jbts_ind = N.jt_ind
         where pr_jbts_ind = O.jt_ind;


create or replace trigger tr_jobtaskA3
after update on jobtask
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.jt_ind <> O.jt_ind) 
      update "FUNCTIONS"
         set fc_jbts_ind = N.jt_ind
         where fc_jbts_ind = O.jt_ind;


create or replace trigger tr_jobtaskA4
after update on jobtask
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.jt_ind <> O.jt_ind) 
      update GROUPTASK
         set jbtsInd = N.jt_ind
         where jbtsInd = O.jt_ind;


create or replace trigger tr_jobtaskA5
after update on jobtask
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.jt_ind <> O.jt_ind) 
      update USERTASK
         set jbtsInd = N.jt_ind
         where jbtsInd = O.jt_ind;


-- Split into 2 updates

create or replace trigger tr_jobtaskB1
after update on jobtask
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.jt_ind <> O.jt_ind) 
      update LASTJOB
         set lj_jbts_ind = N.jt_ind
         where lj_jbts_ind = O.jt_ind;

create or replace trigger tr_jobtaskB2
after update on jobtask
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.jt_ind <> O.jt_ind) 
      update STATIONTASK
         set jbtsInd = N.jt_ind
         where jbtsInd = O.jt_ind;



create or replace trigger tr_dco
after update on dco
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.dco_ind <> O.dco_ind) 
      update dcojob
         set dco_ind = N.dco_ind
         where dco_ind = O.dco_ind;


create or replace trigger tr_taskmod
after update on taskmod
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.ind <> O.ind) 
      update TASKS
         set ts_run_num = N.ind
         where ts_run_num = O.ind;


create or replace trigger tr_tasks
after update on tasks
REFERENCING NEW AS N OLD AS O
for each row
WHEN (N.ts_ind <> O.ts_ind) 
      update JOBTASK
         set jt_task_ind = N.ts_ind
         where jt_task_ind = O.ts_ind;




-- Add some inital data to get Taskmaster started.

--  BUTTONS

insert into BUTTONS(btn_ButtonName, btn_ButtonNumber, btn_BatchSelectionMode, btn_Desc, btn_FileName, btn_IconIndex)
   Values('Scan', 0, 1, 'Scan from Disk', 'TMCLIENT.EXE', 17);
insert into BUTTONS(btn_ButtonName, btn_ButtonNumber, btn_BatchSelectionMode, btn_Desc, btn_FileName, btn_IconIndex)
   Values('Recog', 1, 2, 'Recognition', 'TMCLIENT.EXE', 25);
insert into BUTTONS(btn_ButtonName, btn_ButtonNumber, btn_BatchSelectionMode, btn_Desc, btn_FileName, btn_IconIndex)
   Values('Verify/FixUp', 2, 2, 'Verification', 'TMCLIENT.EXE', 8);
insert into BUTTONS(btn_ButtonName, btn_ButtonNumber, btn_BatchSelectionMode, btn_Desc, btn_FileName, btn_IconIndex)
   Values('Background', 3, 1, 'Background Processing', 'TMCLIENT.EXE', 0);
insert into BUTTONS(btn_ButtonName, btn_ButtonNumber, btn_BatchSelectionMode, btn_Desc, btn_FileName, btn_IconIndex)
   Values('Export', 4, 2, 'Export Data', 'TMCLIENT.EXE', 12);


--  DCO

insert into DCO(dco_id, dco_description, dco_oleid, dco_setupParam, dco_runParam, dco_ind, dco_setup)
   Values('NewApp', ' ', '', '', '', 0, '');


--  JOB

insert into JOB(jb_id, jb_desc, jb_priority, jb_fs, jb_ind)
   Values(' ', ' ', 5, ' ', -1);


--  STATION

insert into STATION(Sta_id, Sta_desc, In_use, sta_user, sta_task, sta_loginTime, sta_quid, sta_logoutTime, sta_running, sta_ind, sta_maxN, sta_N)
   Values('1', 'Default station ID', 0, 0, 0, '2011-09-01 00:00:01', 0, '2011-09-01 00:00:01', 0, 0, 0, 0);
insert into STATION(Sta_id, Sta_desc, In_use, sta_user, sta_task, sta_loginTime, sta_quid, sta_logoutTime, sta_running, sta_ind, sta_maxN, sta_N)
   Values('1-rpt', 'Report Viewer from Station 1', 0, 0, 0, '2011-09-01 00:00:01', 0, '2011-09-01 00:00:01', 0, 2, 0, 0);
insert into STATION(Sta_id, Sta_desc, In_use, sta_user, sta_task, sta_loginTime, sta_quid, sta_logoutTime, sta_running, sta_ind, sta_maxN, sta_N)
   Values('2', ' ', 0, 0, 0, '2011-09-01 00:00:01', 0, '2011-09-01 00:00:01', 0, 1, 0, 0);


--  TASKMOD

insert into TASKMOD(ind, md_name, md_desc, md_exe, md_appsign, md_creative, md_table, md_field, md_params)
   Values(-1, 'Empty', '', '', '', 0, '', '', '');


--  TASKS

insert into TASKS(ts_id, ts_desc, ts_run_num, ts_mon, ts_options, ts_ind, ts_decis, ts_RunWhoWhere, ts_storeIDs)
   Values('', '', -1, 0, '', -1, -1, 0, 0);


--  JOBTASK

insert into JOBTASK(jt_order, jt_job_ind, jt_task_ind, jt_ind)
   Values(0, -1, -1, -1);


--  TMGROUP

insert into TMGROUP(gr_ind, gr_name, gr_desc)
   Values(-1, 'Everyone', ' ');


--  TMUSER

insert into TMUSER(us_id, us_name, us_pass, us_perm, us_ind)
      Values('admin', '', '247030098058198', -1, 0);


--  GROUPTASK

insert into GROUPTASK(GroupInd, jbtsInd)
   Values(-1, -1);

--  STATIONTASK


insert into STATIONTASK(stationInd, jbtsInd)
   Values(0, -1);
insert into STATIONTASK(stationInd, jbtsInd)
   Values(1, -1);


--  USERGROUP

insert into USERGROUP(ug_groupind, ug_userind)
   Values(-1, 0);


--  USERTASK

insert into USERTASK(UserInd, jbtsInd)
   Values(0, -1);


--  ADMINFO

-- The last value is 0 for the DB schema is compatable to TM 7.5, 7.6 and 8.0.
insert into ADMINFO(db_id, db_loc, db_apptitle, db_index, db_version)
   Values('Admin', 'none', 'New App', 7, 0);

