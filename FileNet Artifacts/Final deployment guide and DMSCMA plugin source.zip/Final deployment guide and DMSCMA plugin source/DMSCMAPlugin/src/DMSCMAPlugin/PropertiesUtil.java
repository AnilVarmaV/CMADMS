package DMSCMAPlugin;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesUtil {
		
	private static Properties props =null;

	public static Properties getInstance(){
		try{
			if(props!= null ){
				return props;
			}
			props=new Properties();
			InputStream inputStream = new FileInputStream("C:\\Plugin\\UpdateValues.properties");
			props.load(inputStream);
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return props;
	}
	
	public static void readCEConnDetails(){
		props = getInstance();
	}
	}
