require(["dojo/_base/declare",
         "dojo/_base/lang",
         "dojo/dom-class",
         "ecm/widget/process/StepProcessorLayout" ], 
         function(declare, lang,domClass,StepProcessorLayout) {		
	/**
	 * Use this function to add any global JavaScript methods your plug-in requires.
	 */

	lang.extend(StepProcessorLayout, {
		addProcessButtons: function() {
			try{
				console.log("custom addProcessButtons");
				ecm.model.desktop.loadMenuActions("StepProcessorToolbarP8", lang.hitch(this, function(actions) {
					var buttonAdded = false;
					var queueType = this._workItem.queue_type;
					for ( var i in actions) {
						var action = actions[i];
						if (action.id == "MoveToInbox") {
							if (this._movetoInboxButton) {
							this._movetoInboxButton.destroyRecursive();
							this._movetoInboxButton = null;
						}
						if (queueType && queueType == "processQueue") {
							this._movetoInboxButton = this.processorButtonBar.createMovetoInboxButton(lang.hitch(this, this.onMovetoInbox));
							buttonAdded = true;
						}
						} else if (action.id == "ReturnToSender") {
							if (this._returnButton) {
								this._returnButton.destroyRecursive();
								this._returnButton = null;
							}
							if (queueType && queueType == "userQueue") {
								if (this._workItem.can_return) {
									this._returnButton = this.processorButtonBar.createReturnButton(lang.hitch(this, this.onReturn));
									buttonAdded = true;
								}
							}
						} else if (action.id == "Reassign") {
							if (this._returnButton) {
								this._returnButton.destroyRecursive();
								this._returnButton = null;
							}
							if (this._workItem.can_reassign) {
								this._returnButton = this.processorButtonBar.createReassignButton(lang.hitch(this, this.onReassign));
								buttonAdded = true;
							}
						}
					}
					this.processorButtonBar.addSeparator(buttonAdded);
					this.addResponseButtons(this.processorButtonBar, false, this._messages.process_complete_button_label);
					this.resizeIt();
					this.onProcessButtonsCreated();
					console.log("before Buttons Remove");
					console.log("this ::",this);
					console.log("this.saveButton",this.saveButton);
					domClass.add(this.saveButton.domNode, "dijitHidden");
					console.log("this._movetoInboxButton",this._movetoInboxButton);
					domClass.add(this._movetoInboxButton.domNode, "dijitHidden");
					/*this.saveButton.set('Hidden',true);
					this._movetoInboxButton.set('Hidden',true);*/
					
				}));
				console.log("custom addProcessButtons Ends");
			}
			catch(exp)
			{
				console.log('exception ::',exp);
			}
		},
	});
});