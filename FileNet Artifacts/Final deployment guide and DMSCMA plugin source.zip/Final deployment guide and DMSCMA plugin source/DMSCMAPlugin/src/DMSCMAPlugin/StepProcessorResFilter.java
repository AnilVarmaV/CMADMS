package DMSCMAPlugin;
import java.util.Iterator;
import java.util.Properties;
import javax.servlet.http.HttpServletRequest;
import com.ibm.ecm.extension.PluginResponseFilter;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.json.JSONResponse;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
public class StepProcessorResFilter extends PluginResponseFilter
{
	Properties props = PropertiesUtil.getInstance();
	@Override
	public void filter(String arg0, PluginServiceCallbacks arg1, HttpServletRequest request, JSONObject jsonResponse)
			throws Exception {
		// TODO Auto-generated method stub

		System.out.println("Steprocesor Responce Filter Start");
		JSONResponse jsonResultSetResponse = (JSONResponse) jsonResponse;
		System.out.println("Steprocesor Responce Filter jsonResponse ::"+jsonResultSetResponse);
		String workclass_name = (String)jsonResultSetResponse.get("workclass_name");
		if(workclass_name !=null && workclass_name.equals(props.getProperty("EdelweissDMS")))
		{
			JSONArray jsonProperties = (JSONArray)jsonResultSetResponse.get("criterias");
			updateJSONPropertiesOrder(jsonProperties);
			JSONArray  tempJsonProperties= jsonProperties;
			int propSize = jsonProperties.size();
			Iterator<JSONObject> iterator =  jsonProperties.iterator();
			int index=0;
			while (iterator.hasNext()) {
				JSONObject jsonObject = (JSONObject) iterator.next();

				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("SBU"))
				{
					jsonObject.put("label", "SBU");
					jsonObject.put("promptText", props.getProperty("SBU"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("Client"))
				{
					jsonObject.put("label", "Clinet Name");
					jsonObject.put("promptText", props.getProperty("Client"));			
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("LOB"))
				{
					jsonObject.put("label", "LOB");
					jsonObject.put("promptText", props.getProperty("LOB"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("RecordClassification"))
				{
					jsonObject.put("label", "Record Classification");
					jsonObject.put("promptText", props.getProperty("RecordClassification"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("DMPartner"))
				{
					jsonObject.put("label", "DM Partner");
					jsonObject.put("promptText",  props.getProperty("DMPartner"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("RetentionPeriod"))
				{
					jsonObject.put("label", "Retention Period");
					jsonObject.put("promptText",props.getProperty("RetentionPeriod"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("RecordName"))
				{
					jsonObject.put("label", "Record Name ");
					jsonObject.put("promptText", props.getProperty("RecordName"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("PacketID"))
				{
					jsonObject.put("label", "Packet ID");
					jsonObject.put("promptText",  props.getProperty("PacketID"));		}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("DateofArchival"))
				{
					jsonObject.put("label", "Date of Archival");
					jsonObject.put("promptText", props.getProperty("DateofArchival"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("Entity"))
				{
					jsonObject.put("label", "Entity");
					jsonObject.put("promptText", props.getProperty("Entity"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("Product"))
				{
					jsonObject.put("label", "Product");
					jsonObject.put("promptText", props.getProperty("Product"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("Filebarcode"))
				{
					jsonObject.put("promptText", props.getProperty("Filebarcode"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("Boxbarcode"))
				{
					jsonObject.put("promptText", props.getProperty("Boxbarcode"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("AdditionalHashtag1"))
				{
					jsonObject.put("label", "Additional Hashtag 1");
					jsonObject.put("promptText", props.getProperty("AdditionalHashtag1"));
				}
				if(jsonObject.get("name") != null && jsonObject.get("name").toString().equalsIgnoreCase("AdditionalHashtag2"))
				{
					jsonObject.put("label", "Additional Hashtag 2");
					jsonObject.put("promptText", props.getProperty("AdditionalHashtag2"));
				}
				index++;
				jsonObject=null;
			}
			jsonResultSetResponse.put("criterias", tempJsonProperties);
		}
		System.out.println("Steprocesor Responce Filter End");
	}
	public void updateJSONPropertiesOrder(JSONArray jsonProperties){

		Properties prop = PropertiesUtil.getInstance();
		String[] properties = prop.getProperty("PropertiesOrder").split(",");
		System.out.println("Properties:::::::::::"+properties);
		String[] PropertiesOrder = properties;  
		for (int i = 0; i < PropertiesOrder.length; i++) {
			for (int j = 0; j < jsonProperties.size(); j++) {
				JSONObject jsonProperty = (JSONObject)jsonProperties.get(j);
				if (jsonProperty.get("name").toString().equalsIgnoreCase(PropertiesOrder[i])) {
					JSONObject jsonEDSProperty = (JSONObject)jsonProperties.get(j);
					jsonProperties.add(i, jsonEDSProperty);
					jsonProperties.remove(j+1);
				}
			}
		}
	}
	@Override
	public String[] getFilteredServices() {
		// TODO Auto-generated method stub
		return new String[] {"/p8/getStepParameters"};
	}
}
